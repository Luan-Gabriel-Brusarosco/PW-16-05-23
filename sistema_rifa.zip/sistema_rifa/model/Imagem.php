<?php

Class Imagem{
    public int      $id;
    public string   $fk_Rifa_id;
    public string   $link_img;
    public string   $creation_time;
    public string   $modification_time;

    public function __construct($c=0, $id=0, $fk_Rifa_id="", $link_img="", $creation_time="", $modification_time="") {
        if($c){
          $this->id = $id;
          $this->fk_Rifa_id =  $fk_Rifa_id;
          $this->link_img = $link_img;
          $this->creation_time = $creation_time;
          $this->modification_time = $modification_time;
        }
      }
    
      

  public function getId() {
    return $this->id;
  }

  public function setId($id) {
    $this->id = $id;
  }

  public function getRifaId() {
    return $this->fk_Rifa_id;
  }

  public function setRifaId($fk_Rifa_id) {
    $this->fk_Rifa_id = $fk_Rifa_id;
  }

  public function getLinkImg() {
    return $this->link_img;
  }

  public function setLinkImg($link_img) {
    $this->link_img = $link_img;
  }

  public function getCreationTime() {
    return $this->creation_time;
  }

  public function setCreationTime($creation_time) {
    $this->creation_time = $creation_time;
  }

  public function getModificationTime() {
    return $this->modification_time;
  }

  public function setModificationTime($modification_time) {
    $this->modification_time = $modification_time;
  }

}
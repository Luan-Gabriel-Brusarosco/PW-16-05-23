<?php
require_once 'DataBase.php';
require_once 'Imagem.php';
class UsuarioDAO
{
    private $pdo;
    private $erro;

    public function getErro(){
        return $this->erro;
    }

    public function __construct()
    {
        try {
            $this->pdo = (new DataBase())->connection();
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (\PDOException $e) {
            $this->erro = 'Erro ao conectar com o banco de dados: ' . $e->getMessage();
            die;
        }
    }



    public function insert(Usuario $usuario): Usuario|bool
    {
        $stmt = $this->pdo->prepare("INSERT INTO Imagens (fk_Rifa_id, link_img, creation_time, modification_time) VALUES (:fk_Rifa_id,:link_img,:creation_time,:modification_time)");
        $dados = [
            'fk_Rifa_id'            => $imagem->getRifaId(),
            'link_img'              => $imagem->getLinkImg(),
            'creation_time'         => $imagem->getCreationTime(),
            'modification_time'     => $imagem->getModificationTime(),
        ];
        try {
            $stmt->execute($dados);
            return $this->selectById($this->pdo->lastInsertId());
        } catch (\PDOException $e) {
            $this->erro = 'Erro ao inserir usuário: ' . $e->getMessage();
            return false;
        }
    }

    public function selectById($id): Imagem|bool
    {
        $stmt = $this->pdo->prepare("SELECT * FROM Imagens WHERE Imagens.id = :id");
        try {
            if($stmt->execute(['id'=>$id])){
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                return (new Imgem($row['id'], $row['fk_Rifa_id'], $row['link_img'], $row['creation_time'], $row['modification_time']));
            }
            return false;   

        } catch (\PDOException $e) {
            $this->erro = 'Erro ao selecionar imagem: ' . $e->getMessage();
            return false;
        }
    }

    public function listarTodos(){
        $cmdSql = "SELECT * FROM Imagens";
        $cx = $this->pdo->prepare($cmdSql);
        $cx->execute();
        if($cx->rowCount() > 0){
            $cx->setFetchMode(PDO::FETCH_CLASS, 'Imagens');
            return $cx->fetchAll();
        }
        return false;
    }

    public function select($filtro=""):array|bool{
        $cmdSql = 'SELECT * FROM imagens WHERE fk_Rifa_id LIKE :fk_Rifa_id OR link_img LIKE :link_img OR creation_time LIKE :creation_time OR modification_time LIKE :modification_time';
        try{
            $cx = $this->pdo->prepare($cmdSql);
            $cx->bindValue(':fk_Rifa_id',"%$filtro%");
            $cx->bindValue(':link_img',"%$filtro%");
            $cx->bindValue(':creation_time',"%$filtro%");
            $cx->bindValue(':modification_time',"%$filtro%");
            $cx->execute();
            $cx->setFetchMode(PDO::FETCH_CLASS, 'Imagens');
            return $cx->fetchAll();
        }
        catch (\PDOException $e) {
            $this->erro = 'Erro ao selecionar imagem: ' . $e->getMessage();
            return false;
        }
    }

    public function selectByLinkImg($fk_Rifa_id="")
    {
        $stmt = $this->pdo->prepare("SELECT * FROM Imagem WHERE link_img LIKE :link_img");
        $link_img = '%' . $link_img . '%';
        try {
            $stmt->execute(['link_img'=>$link_img]);
            return $stmt->fetchAll(PDO::FETCH_CLASS,"Imagem");
        } catch (PDOException $e) {
            throw new Exception('Erro ao selecionar imagem por link: ' . $e->getMessage());
        }
    }
      

    public function update(Imagem $imagem)
    {
        $stmt = $this->pdo->prepare("UPDATE Imagens SET fk_Rifa_id = ?, link_img = ?, creation_time = ?, modification_time = ? WHERE id = ?");
        $fk_Rifa_id             = $imagem->getRifaId();
        $link_img               = $imagem->getLinkImg();
        $creation_time          = $imagem->getCreationTime();
        $modification_time      = $imagem->getModificationTime();
        $id                     = $imagem->getId();
        try {
            $stmt->execute([$fk_Rifa_id, $link_img, $creation_time, $modification_time, $id]);
            return $stmt->rowCount();
        } catch (PDOException $e) {
            throw new Exception('Erro ao atualizar imagem: ' . $e->getMessage());
        }
    }

    public function deleteById($id)
    {
        $stmt = $this->pdo->prepare("DELETE FROM Imagens WHERE id = ?");
        try {
            $stmt->execute([$id]);
            return $stmt->rowCount();
        } catch (PDOException $e) {
            throw new Exception('Erro ao excluir imagem: ' . $e->getMessage());
        }
    }

    public function __destruct()
    {
        $this->pdo = null;
    }
}